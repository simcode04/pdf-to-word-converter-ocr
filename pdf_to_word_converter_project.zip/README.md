# PDF to Word Converter

This is a simple **PDF to Word Converter** built using **Flask**.

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/pdf-to-word-converter.git
   cd pdf-to-word-converter
   ```
2. Install dependencies:
   ```bash
   pip install flask pdf2docx werkzeug
   ```
3. Run the Flask app:
   ```bash
   python app.py
   ```
4. Open **http://127.0.0.1:5000/** in your browser.
